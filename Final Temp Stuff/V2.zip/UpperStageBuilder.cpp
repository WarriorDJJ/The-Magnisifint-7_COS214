#include "UpperStageBuilder.h"

void UpperStageBuilder::createRocket() {
	// TODO - implement UpperStageBuilder::createRocket
	throw "Not yet implemented";
}

void UpperStageBuilder::createEngines() {
	// TODO - implement UpperStageBuilder::createEngines
	throw "Not yet implemented";
}
