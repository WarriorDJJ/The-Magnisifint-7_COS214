#ifndef UPPERSTAGEBUILDER_H
#define UPPERSTAGEBUILDER_H

#include "RocketBuilder.h"

class UpperStageBuilder : public RocketBuilder {


public:
	void createRocket();

	void createEngines();
};

#endif
