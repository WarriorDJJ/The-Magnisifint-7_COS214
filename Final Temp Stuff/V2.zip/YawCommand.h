//
// Created by djjor on 2021-11-17.
//

#ifndef INC_214PROJECT_YAWCOMMAND_H
#define INC_214PROJECT_YAWCOMMAND_H


class YawCommand {

};


#endif //INC_214PROJECT_YAWCOMMAND_H
