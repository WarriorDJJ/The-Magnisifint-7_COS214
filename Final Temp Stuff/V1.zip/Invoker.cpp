#include "Invoker.h"

Invoker::Invoker(Command* c) {
	// TODO - implement Invoker::Invoker
	throw "Not yet implemented";
}

void Invoker::press() {
	// TODO - implement Invoker::press
	throw "Not yet implemented";
}
