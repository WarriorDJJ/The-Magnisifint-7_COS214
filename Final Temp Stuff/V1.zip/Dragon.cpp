//
// Created by djjor on 2021-11-22.
//

#include "Dragon.h"

void Dragon::LoadFuel()
{
    //stubbed
    return;
}

double Dragon::GetFuel()
{
    //stubbed
    return 0;
}
//smoove -k,f xd
void Dragon::VentFuel()
{
    //stubbed
    return;
}
//what else ?


