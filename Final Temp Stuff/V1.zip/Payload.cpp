#include "Payload.h"

void Payload::Activate() {
	// TODO - implement Payload::Activate
	throw "Not yet implemented";
}

Payload * Payload::clone() {
	// TODO - implement Payload::clone
	throw "Not yet implemented";
}
