#include "EngineFactory.h"

/*Engine* EngineFactory::createVacuumEngine() {
	// TODO - implement EngineFactory::createVacuumEngine
	throw "Not yet implemented";
}

Engine* EngineFactory::createStandardEngine() {
	// TODO - implement EngineFactory::createStandardEngine
	throw "Not yet implemented";
}
*/