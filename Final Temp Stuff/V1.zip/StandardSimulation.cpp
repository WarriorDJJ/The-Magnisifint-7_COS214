#include "StandardSimulation.h"

void StandardSimulation::launch() {
	// TODO - implement StandardSimulation::launch
	throw "Not yet implemented";
}
