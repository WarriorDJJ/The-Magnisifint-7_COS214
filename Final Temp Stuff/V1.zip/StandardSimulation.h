#ifndef STANDARDSIMULATION_H
#define STANDARDSIMULATION_H
#include "Simulation.h"

class StandardSimulation : public Simulation {


public:
	void launch();
};

#endif
