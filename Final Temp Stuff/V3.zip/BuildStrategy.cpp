#include "BuildStrategy.h"

void BuildStrategy::setBuilder(RocketBuilder *rb) {
    builder = nullptr;
    builder = rb;
}