//
// Created by djjor on 2021-11-17.
//

#ifndef INC_214PROJECT_ROLLCOMMAND_H
#define INC_214PROJECT_ROLLCOMMAND_H


class RollCommand {

};


#endif //INC_214PROJECT_ROLLCOMMAND_H
