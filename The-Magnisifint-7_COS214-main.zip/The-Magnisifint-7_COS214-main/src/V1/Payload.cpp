#include "Payload.h"

string Payload::getName(){
    return "(payload)"; //damian told me to code it this way// noice
}

