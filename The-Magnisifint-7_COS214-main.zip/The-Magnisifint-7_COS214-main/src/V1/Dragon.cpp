//
// Created by djjor on 2021-11-22.
//

#include "Dragon.h"

void Dragon::LoadFuel()
{

}

double Dragon::GetFuel()
{
    return 0;
}
//smoove -k,f xd
void Dragon::VentFuel()
{
    //stubbed
    return;
}
//what else ?

void Dragon::Activate(){
    cout<< this->getName() << " Docked to the international space station."<<endl;
}


